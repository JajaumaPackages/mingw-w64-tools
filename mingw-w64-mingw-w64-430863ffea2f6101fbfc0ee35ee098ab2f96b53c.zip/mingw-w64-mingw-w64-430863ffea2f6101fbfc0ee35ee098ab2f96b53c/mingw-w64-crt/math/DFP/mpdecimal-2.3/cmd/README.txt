

This directory contains a number of examples. In order to compile, run
(for example):

gcc -Wall -W -O2 -o powmod powmod.c ../libmpdec.a -lm


